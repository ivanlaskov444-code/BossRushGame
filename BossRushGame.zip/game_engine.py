from PyQt6 import QtWidgets, QtCore, QtGui
import os


class GameWindow(QtWidgets.QMainWindow):
    def __init__(self, player_data, db):
        super().__init__()
        print("🚀 Создаем игровое окно...")
        self.player_data = player_data
        self.db = db
        self.setup_game()

    def setup_game(self):
        # ФИКСИРОВАННЫЙ размер окна
        self.WINDOW_WIDTH = 1200
        self.WINDOW_HEIGHT = 800

        # Центрируем окно на экране
        self.setFixedSize(self.WINDOW_WIDTH, self.WINDOW_HEIGHT)
        self.center_window()

        self.setWindowTitle("Boss Rush - Игра")

        # Игровая сцена - виртуальный мир
        self.game_scene = QtWidgets.QGraphicsScene()
        self.game_scene.setSceneRect(0, 0, self.WINDOW_WIDTH, self.WINDOW_HEIGHT)
        self.game_scene.setBackgroundBrush(QtGui.QColor(0, 0, 0))

        self.game_view = QtWidgets.QGraphicsView(self.game_scene)
        self.game_view.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.game_view.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setCentralWidget(self.game_view)

        # УСТАНАВЛИВАЕМ ФОКУС НА ИГРОВОМ ОКНЕ!
        self.game_view.setFocusPolicy(QtCore.Qt.FocusPolicy.StrongFocus)
        self.game_view.setFocus()

        # Создаем линию-пол
        self.create_floor_line()

        # СОЗДАЕМ ПЛАТФОРМЫ
        self.platforms = []
        self.create_platforms()

        # Загружаем анимации персонажа
        self.load_player_animations()

        # Создаем игрока
        self.create_player()

        # Настраиваем управление и физику
        self.setup_controls()

        print("✅ Игра готова! A/D - движение, Space - прыжок")
        print("💡 СОВЕТ: Нажмите на игровое окно чтобы активировать управление!")

    def center_window(self):
        screen = QtWidgets.QApplication.primaryScreen()
        screen_rect = screen.availableGeometry()

        x = (screen_rect.width() - self.WINDOW_WIDTH) // 2
        y = (screen_rect.height() - self.WINDOW_HEIGHT) // 2

        self.move(x, y)

    def create_floor_line(self):

        line_height = 40
        self.floor_line = QtWidgets.QGraphicsRectItem(0, 0, self.WINDOW_WIDTH, line_height)
        self.floor_line.setBrush(QtGui.QBrush(QtGui.QColor(255, 255, 0)))
        self.floor_line.setPen(QtGui.QPen(QtGui.QColor(255, 0, 0), 3))

        floor_y = self.WINDOW_HEIGHT - line_height
        self.floor_line.setPos(0, floor_y)
        self.game_scene.addItem(self.floor_line)

        self.FLOOR_Y = floor_y  # Сохраняем Y-координату пола

    def create_platforms(self):

        platforms_data = [
            # Первый уровень
            (200, 600, 300, 20),
            (600, 600, 200, 20),

            # Второй уровень
            (100, 500, 200, 20),
            (500, 500, 150, 20),
            (800, 500, 180, 20),

            # Третий уровень
            (300, 400, 250, 20),
            (650, 400, 120, 20),

            # Четвертый уровень
            (150, 300, 180, 20),
            (500, 300, 200, 20),
            (800, 300, 150, 20),

            # Пятый уровень
            (350, 200, 100, 20),
            (700, 200, 120, 20),
        ]

        for i, (x, y, width, height) in enumerate(platforms_data):
            platform = QtWidgets.QGraphicsRectItem(0, 0, width, height)

            # Разные цвета
            if y >= 550:
                platform.setBrush(QtGui.QBrush(QtGui.QColor(100, 200, 100)))
            elif y >= 450:
                platform.setBrush(QtGui.QBrush(QtGui.QColor(200, 200, 100)))
            elif y >= 350:
                platform.setBrush(QtGui.QBrush(QtGui.QColor(200, 150, 50)))
            else:
                platform.setBrush(QtGui.QBrush(QtGui.QColor(200, 100, 100)))

            platform.setPen(QtGui.QPen(QtGui.QColor(255, 255, 255), 2))
            platform.setPos(x, y)
            self.game_scene.addItem(platform)
            self.platforms.append(platform)

            # Определяем сложность
            if y >= 550:
                difficulty = "ЛЕГКО"
            elif y >= 450:
                difficulty = "СРЕДНЕ"
            elif y >= 350:
                difficulty = "СЛОЖНО"
            else:
                difficulty = "ЭКСПЕРТ"

    def load_player_animations(self): #Загружаем анимации персонажа

        self.walk_frames = []
        self.current_frame = 0
        self.is_walking = False
        self.facing_right = True  # Направление взгляда персонажа

        walk_files = ["Pers_1.jpg", "Pers_2.jpg", "Pers_1.jpg", "Pers_3.jpg"]

        try:
            for i, filename in enumerate(walk_files):
                if os.path.exists(filename):
                    pixmap = QtGui.QPixmap(filename)
                    pixmap = pixmap.scaled(40, 60, QtCore.Qt.AspectRatioMode.KeepAspectRatio)
                    self.walk_frames.append(pixmap)
                else:
                    self.create_fallback_animation()
                    break

            if not self.walk_frames:
                self.create_fallback_animation()

        except Exception as e:
            self.create_fallback_animation()

    def create_fallback_animation(self):# запасная анимация
        self.walk_frames = []

        colors = [
            QtGui.QColor(255, 255, 255),
            QtGui.QColor(200, 200, 255),
            QtGui.QColor(255, 255, 255),
            QtGui.QColor(255, 200, 200)
        ]

        for color in colors:
            pixmap = QtGui.QPixmap(60, 80)
            pixmap.fill(color)
            self.walk_frames.append(pixmap)

    def create_player(self):#Создаем анимированного игрока

        self.player = QtWidgets.QGraphicsPixmapItem()

        if self.walk_frames:
            self.player.setPixmap(self.walk_frames[0])  # Устанавливаем первый кадр анимации
        else:
            self.create_fallback_player()

        player_x = 100
        player_y = self.FLOOR_Y - 80  # Ставим игрока над полом
        self.player.setPos(player_x, player_y)
        self.game_scene.addItem(self.player)

        # Создаем метку над игроком
        self.player_label = QtWidgets.QGraphicsTextItem("Игрок")
        self.player_label.setDefaultTextColor(QtGui.QColor(255, 255, 0))
        self.player_label.setScale(1)
        self.update_player_label_position()
        self.game_scene.addItem(self.player_label)

        self.START_Y = player_y  # Сохраняем стартовую позицию

    def create_fallback_player(self):#Создаем запасного персонажа
        pixmap = QtGui.QPixmap(60, 80)
        pixmap.fill(QtGui.QColor(255, 255, 255))  # Белый квадрат
        self.player.setPixmap(pixmap)

    def update_player_label_position(self):#Обновляем позицию надписи относительно игрока
        player_x = self.player.x()
        player_y = self.player.y()
        self.player_label.setPos(player_x, player_y - 50)  # На 50px выше игрока

    def setup_controls(self):#Настраиваем управление, физику и игровые таймеры
        self.moving_left = False
        self.moving_right = False
        self.player_speed = 5

        # Физика прыжка
        self.is_jumping = False
        self.player_velocity_y = 0  # Вертикальная скорость
        self.jump_power = -17  # Начальная скорость прыжка
        self.gravity = 0.9  # Сила гравитации
        self.on_ground = True

        # БУФЕР ПРЫЖКА - решает проблему с запаздывающими нажатиями
        self.jump_buffer = 0  # Счетчик кадров для буферизации прыжка
        self.jump_buffer_max = 10  # Максимальное время буферизации

        # Сохраняем предыдущую позицию для улучшенной проверки коллизий
        self.prev_player_y = self.player.y() if hasattr(self, 'player') else 0

        # Таймер для движения - вызывает game_loop каждые 16мс
        self.game_timer = QtCore.QTimer()
        self.game_timer.timeout.connect(self.game_loop)
        self.game_timer.start(16)

        # Таймер для анимации - обновляет кадры анимации каждые 200мс
        self.animation_timer = QtCore.QTimer()
        self.animation_timer.timeout.connect(self.update_animation)
        self.animation_timer.start(200)

    def check_collisions(self):#проверка столкновений с полом и платформами
        player_rect = self.player.sceneBoundingRect()
        player_bottom = player_rect.bottom()
        player_left = player_rect.left()
        player_right = player_rect.right()
        player_top = player_rect.top()

        # Сохраняем текущую позицию для следующего кадра
        current_y = self.player.y()

        # Сначала проверяем пол
        floor_rect = self.floor_line.sceneBoundingRect()
        if (player_bottom >= floor_rect.top() and
                player_top < floor_rect.bottom() and
                self.player_velocity_y >= 0):
            self.player.setY(floor_rect.top() - player_rect.height())
            self.player_velocity_y = 0
            self.on_ground = True
            self.is_jumping = False
            self.prev_player_y = self.player.y()
            return True

        # Проверяем ВСЕ платформы на столкновение
        found_platform = False

        for platform in self.platforms:
            platform_rect = platform.sceneBoundingRect()

            # ОСНОВНАЯ проверка: игрок над платформой и падает вниз
            is_above_platform = (
                    player_bottom >= platform_rect.top() - 5 and
                    player_bottom <= platform_rect.top() + 25 and
                    player_top < platform_rect.bottom() and
                    player_right > platform_rect.left() + 5 and
                    player_left < platform_rect.right() - 5 and
                    self.player_velocity_y >= 0
            )

            # ДОПОЛНИТЕЛЬНАЯ проверка: предотвращаем проскакивание платформ
            # Проверяем, не пролетел ли игрок сквозь платформу между кадрами
            prev_player_bottom = self.prev_player_y + player_rect.height()
            passed_through_platform = (
                    prev_player_bottom <= platform_rect.top() and  # В предыдущем кадре был выше платформы
                    player_bottom >= platform_rect.top() and  # В текущем кадре ниже платформы
                    player_right > platform_rect.left() + 5 and
                    player_left < platform_rect.right() - 5 and
                    self.player_velocity_y > 0  # Двигался вниз
            )

            if is_above_platform or passed_through_platform:
                # Нашли платформу под ногами - приземляемся
                self.player.setY(platform_rect.top() - player_rect.height())
                self.player_velocity_y = 0
                self.on_ground = True
                self.is_jumping = False
                found_platform = True
                break

        # Сохраняем позицию для следующего кадра
        self.prev_player_y = current_y

        # Если не нашли ни одной платформы под ногами - тогда мы в воздухе
        if not found_platform:
            self.on_ground = False

        return found_platform

    def update_animation(self):#Обновляем анимацию персонажа
        if not self.walk_frames:
            return

        # Переключаем кадры анимации если игрок движется
        if self.is_walking:
            self.current_frame = (self.current_frame + 1) % len(self.walk_frames)
        else:
            self.current_frame = 0  # Останавливаем на первом кадре

        current_pixmap = self.walk_frames[self.current_frame]

        # Отражаем изображение если смотрим влево
        if not self.facing_right:
            mirrored = current_pixmap.transformed(QtGui.QTransform().scale(-1, 1))
            self.player.setPixmap(mirrored)
        else:
            self.player.setPixmap(current_pixmap)

    def keyPressEvent(self, event):#Обрабатываем нажатия клавиш
        if event.key() == QtCore.Qt.Key.Key_A:
            self.moving_left = True
            self.facing_right = False
            self.is_walking = True
        elif event.key() == QtCore.Qt.Key.Key_D:
            self.moving_right = True
            self.facing_right = True
            self.is_walking = True
        elif event.key() == QtCore.Qt.Key.Key_Space:
            # ВКЛЮЧАЕМ БУФЕР ПРЫЖКА при нажатии пробела
            self.jump_buffer = self.jump_buffer_max
        elif event.key() == QtCore.Qt.Key.Key_Escape:
            self.close()

    def keyReleaseEvent(self, event):#Обрабатываем отпускание клавиш
        if event.key() == QtCore.Qt.Key.Key_A:
            self.moving_left = False
            if not self.moving_right:
                self.is_walking = False
        elif event.key() == QtCore.Qt.Key.Key_D:
            self.moving_right = False
            if not self.moving_left:
                self.is_walking = False

    def handle_jump(self):#Обрабатываем прыжок и гравитацию
        # Всегда применяем гравитацию, если не на земле
        if not self.on_ground:
            self.player_velocity_y += self.gravity
            new_y = self.player.y() + self.player_velocity_y
            self.player.setY(new_y)

        # ПРОВЕРЯЕМ БУФЕР ПРЫЖКА - если есть запрос на прыжок и мы на земле
        if self.jump_buffer > 0 and self.on_ground:
            self.is_jumping = True
            self.player_velocity_y = self.jump_power
            self.on_ground = False
            self.jump_buffer = 0  # Сбрасываем буфер после выполнения прыжка

    def game_loop(self):#Главный игровой цикл - вызывается каждые 16мс
        # УМЕНЬШАЕМ БУФЕР ПРЫЖКА каждый кадр
        if self.jump_buffer > 0:
            self.jump_buffer -= 1

        # Движение влево
        if self.moving_left:
            new_x = self.player.x() - self.player_speed
            if new_x >= 0:  # Проверяем чтобы не выйти за левую границу
                self.player.setX(new_x)

        # Движение вправо
        if self.moving_right:
            new_x = self.player.x() + self.player_speed
            if new_x <= self.WINDOW_WIDTH - 60:  # Проверяем чтобы не выйти за правую границу
                self.player.setX(new_x)

        # Обрабатываем прыжок и гравитацию
        self.handle_jump()

        # Проверяем столкновения с полом и платформами
        self.check_collisions()

        # Обновляем позицию надписи
        self.update_player_label_position()

    def closeEvent(self, event):#Вызывается при закрытии окна
        self.game_timer.stop()
        self.animation_timer.stop()
        event.accept()