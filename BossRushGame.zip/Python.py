import sys
from PyQt6 import QtWidgets
from start_ui import Ui_StartWindow
from register_ui import Ui_RegisterWindow
from login_ui import Ui_EntranceWindow
from database import Database
from main_menu_ui import Ui_MainMenuWindow
from game_engine import GameWindow

class MainMenuWindow(QtWidgets.QMainWindow, Ui_MainMenuWindow):
    def __init__(self, player_data, db):
        super().__init__()
        self.setupUi(self)
        self.player_data = player_data
        self.db = db

        self.play_btn.clicked.connect(self.start_game)
        self.shop_btn.clicked.connect(self.open_shop)
        self.profile_btn.clicked.connect(self.open_profile)
        self.exit_btn.clicked.connect(self.close)

    def start_game(self):
        print("Запуск игры...")
        self.game_window = GameWindow(self.player_data, self.db)
        self.game_window.show()
        self.close()


    def open_shop(self):
        print("Магазин...")
        QtWidgets.QMessageBox.information(self, "Магазин", "Магазин скоро будет!")

    def open_profile(self):
        print("Профиль...")
        QtWidgets.QMessageBox.information(self, "Профиль", "Профиль скоро будет!")


class EntranceWindow(QtWidgets.QMainWindow, Ui_EntranceWindow):  # ВХОД
    def __init__(self, start_window, db):
        super().__init__()
        self.setupUi(self)
        self.start_window = start_window
        self.db = db
        self.error_label.hide()
        self.create_account_btn.clicked.connect(self.handle_login)
        self.cancel_btn.clicked.connect(self.go_back)

    def handle_login(self):
        login = self.login_input.text()
        password = self.password_input.text()

        if not login or not password:
            self.error_label.setText("Заполните все поля!")
            self.error_label.show()
            return

        success, message, player_data = self.db.login_player(login, password)

        if success:
            self.error_label.hide()

            # Создаем главное меню
            self.main_menu = MainMenuWindow(player_data, self.db)
            self.main_menu.show()
            self.close()
        else:
            self.error_label.setText(message)
            self.error_label.show()

    def go_back(self):
        self.start_window.show()
        self.close()


class RegisterWindow(QtWidgets.QMainWindow, Ui_RegisterWindow):  # РЕГИСТРАЦИЯ
    def __init__(self, start_window, db):
        super().__init__()
        self.setupUi(self)
        self.start_window = start_window
        self.db = db
        self.error_label.hide()
        self.create_account_btn.clicked.connect(self.handle_register)
        self.cancel_btn.clicked.connect(self.go_back)

    def handle_register(self):
        login = self.login_input.text()
        password = self.password_input.text()
        confirm = self.confirm_password_input.text()

        if password != confirm:
            self.error_label.setText("Пароли не совпадают!")
            self.error_label.show()
            return

        if not login or not password:
            self.error_label.setText("Заполните все поля!")
            self.error_label.show()
            return

        if len(login) < 3:
            self.error_label.setText("Логин должен быть не менее 3 символов!")
            self.error_label.show()
            return

        if len(password) < 4:
            self.error_label.setText("Пароль должен быть не менее 4 символов!")
            self.error_label.show()
            return

        success, message = self.db.register_player(login, password)

        if success:
            self.error_label.hide()
            print(f"✅ Успешная регистрация: {login}")
            QtWidgets.QMessageBox.information(self, "Успех", "Аккаунт создан!")
            self.go_back()
        else:
            self.error_label.setText(message)
            self.error_label.show()


    def go_back(self):
        self.start_window.show()
        self.close()


class StartWindow(QtWidgets.QMainWindow, Ui_StartWindow):  # РЕГИСТРАЦИЯ ИЛИ ВХОД
    def __init__(self, db):
        super().__init__()
        self.setupUi(self)
        self.Login.clicked.connect(self.open_login)
        self.Register.clicked.connect(self.open_register)
        self.db = db

    def open_login(self):
        self.loginog_window = EntranceWindow(self, self.db)
        self.loginog_window.show()
        self.hide()

    def open_register(self):
        self.register_window = RegisterWindow(self, self.db)
        self.register_window.show()
        self.hide()


def main():
    app = QtWidgets.QApplication(sys.argv)
    db = Database()
    start_window = StartWindow(db)
    start_window.show()
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
