from PyQt6 import QtCore, QtGui, QtWidgets


class Ui_StartWindow(object):
    def setupUi(self, StartWindow):
        StartWindow.setObjectName("StartWindow")
        StartWindow.setEnabled(True)
        StartWindow.resize(371, 287)
        StartWindow.setBaseSize(QtCore.QSize(0, 0))
        self.centralwidget = QtWidgets.QWidget(parent=StartWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.Name_game = QtWidgets.QLabel(parent=self.centralwidget)
        self.Name_game.setGeometry(QtCore.QRect(70, 60, 254, 36))
        self.Name_game.setBaseSize(QtCore.QSize(10, 10))
        font = QtGui.QFont()
        font.setFamily("Rockwell Extra Bold")
        font.setPointSize(22)
        font.setBold(True)
        font.setWeight(75)
        self.Name_game.setFont(font)
        self.Name_game.setObjectName("Name_game")
        self.Login = QtWidgets.QPushButton(parent=self.centralwidget)
        self.Login.setGeometry(QtCore.QRect(80, 120, 211, 31))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.Login.setFont(font)
        self.Login.setObjectName("Login")
        self.Register = QtWidgets.QPushButton(parent=self.centralwidget)
        self.Register.setGeometry(QtCore.QRect(70, 160, 231, 31))
        self.Register.setObjectName("Register")
        StartWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(parent=StartWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 371, 21))
        self.menubar.setObjectName("menubar")
        StartWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(parent=StartWindow)
        self.statusbar.setObjectName("statusbar")
        StartWindow.setStatusBar(self.statusbar)

        self.retranslateUi(StartWindow)
        QtCore.QMetaObject.connectSlotsByName(StartWindow)

    def retranslateUi(self, StartWindow):
        _translate = QtCore.QCoreApplication.translate
        StartWindow.setWindowTitle(_translate("StartWindow", "MainWindow"))
        self.Name_game.setText(_translate("StartWindow", "НАЗВАНИЕ ИГРЫ"))
        self.Login.setText(_translate("StartWindow", "Войти"))
        self.Register.setText(_translate("StartWindow", "Зарегистрироваться"))
