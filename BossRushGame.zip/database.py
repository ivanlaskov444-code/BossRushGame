import sqlite3
import hashlib
from datetime import datetime


class Database:
    def __init__(self):
        self.conn = sqlite3.connect('space_shooter.db')
        self.create_tables()

    def create_tables(self):
        cursor = self.conn.cursor()

        # Таблица пользователей
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS players (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                login TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                credits INTEGER DEFAULT 1000,
                level INTEGER DEFAULT 1,
                registration_date TEXT NOT NULL
            )
        ''')

        self.conn.commit()

    def hash_password(self, password):#Хешируем пароль
        return hashlib.sha256(password.encode()).hexdigest()

    def register_player(self, login, password): #Регистрация нового игрока
        cursor = self.conn.cursor()

        try:
            password_hash = self.hash_password(password)
            registration_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            cursor.execute('''
                INSERT INTO players (login, password_hash, credits, level, registration_date)
                VALUES (?, ?, ?, ?, ?)
            ''', (login, password_hash, 1000, 1, registration_date))

            self.conn.commit()
            return True, "Регистрация успешна!"

        except sqlite3.IntegrityError:
            return False, "Логин уже занят!"
        except Exception as e:
            return False, f"Ошибка: {str(e)}"

    def login_player(self, login, password): #Проверка логина и пароля
        cursor = self.conn.cursor()

        password_hash = self.hash_password(password)

        cursor.execute('''
            SELECT id, login, credits, level FROM players 
            WHERE login = ? AND password_hash = ?
        ''', (login, password_hash))

        player = cursor.fetchone()

        if player:
            return True, "Вход успешен!", player
        else:
            return False, "Неверный логин или пароль!", None

    def close(self):
        self.conn.close()